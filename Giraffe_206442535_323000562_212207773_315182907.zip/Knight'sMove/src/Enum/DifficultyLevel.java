package Enum;

public enum DifficultyLevel {
	EASY, MEDIOCRE, HARD
}
