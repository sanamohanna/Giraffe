package Enum;

public enum Directions {
	UP_LEFT, UP_RIGHT, DOWN_LEFT, DOWN_RIGHT , UP ,DOWN , LEFT , RIGHT
}

	  