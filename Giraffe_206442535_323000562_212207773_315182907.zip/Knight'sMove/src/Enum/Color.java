package Enum;

public enum Color {
White , Black , Red;
}
