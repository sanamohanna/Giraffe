package Enum;

public enum GameStatus {
	GameOver, WIN ,LostInLevel1,LostInLevel2,LostInLevel3,LostInLevel4,WinWithCup
}
