package Enum;

public enum GameStatus {
	GameOver, WIN
}
