package model;

import Enum.Color;

//to add the method\
//another check

public class RandomJump extends Squares {

	// constructor
	public RandomJump(Piece peice, Location location, Color color) {
		super(peice, location, color);
		// TODO Auto-generated constructor stub
	}
 
	public void changePlaceToEmptuSquare() {

	}
}
