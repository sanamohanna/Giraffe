package model;

import Enum.Color;

public class Blocked extends Squares{
	//constructor
	public Blocked(Piece peice, Location location, Color color) {
		super(peice, location, color);
	    color = Color.Red;
		// TODO Auto-generated constructor stub
	}

	

   
}
