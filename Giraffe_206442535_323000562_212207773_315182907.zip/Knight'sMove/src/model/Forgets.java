package model;

import Enum.Color;

public class Forgets  extends Squares{
	//constructor
	public Forgets(Piece peice, Location location, Color color) {
		super(peice, location, color);
		// TODO Auto-generated constructor stub
	}

	public void handleLastThreeSteps() {
		
	}

}
