package model;
//import java.util.Timer;  
//import java.util.TimerTask;
//import java.util.concurrent.TimeUnit; 
public class TimerCount{
	static long min,hr, sec, totalSec=0;
 
	
	
}
